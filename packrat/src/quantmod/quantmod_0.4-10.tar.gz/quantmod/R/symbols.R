#
# symbols via yahoo:
#   'http://download.finance.yahoo.com/d/quotes.csv?s=WPP&f=nsl1d1t1c1ohgv'

# symbol list:
#   http://www.nasdaq.com/reference/comlookup.stm#viewdownload
#
#   NASDAQ
#     http://www.nasdaq.com//asp/symbols.asp?exchange=Q&start=0
#   AMEX
#     http://www.nasdaq.com//asp/symbols.asp?exchange=1&start=0
#   NYSE
#     http://www.nasdaq.com//asp/symbols.asp?exchange=N&start=0
#     > NYSE[2]$V2[-grep('\\^|/',NYSE[2]$V2,perl=TRUE)]

