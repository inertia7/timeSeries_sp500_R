FD_EXTERNAL
struct { int igamma, jgamma; } gammfd_;
