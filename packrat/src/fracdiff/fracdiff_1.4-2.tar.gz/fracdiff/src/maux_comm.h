FD_EXTERNAL
struct { double epsp25, epspt3, epspt5, epsp75, bignum; } mauxfd_;
#define mauxfd_1 mauxfd_

