octal <- "\012"
hex   <- "\xE2\x99\xA5"
utf8  <- "\u2665"
