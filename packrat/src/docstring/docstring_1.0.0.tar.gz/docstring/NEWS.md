NEWS
==========

CHANGES IN docstring VERSION 1.0.0
---------------------------------

* This is the initial release.